package com.open.api.sdk.weid;

import cn.hutool.json.JSONObject;
import com.open.api.sdk.client.fisco.MultiFiscoClient;
import com.open.api.sdk.util.CommonUtil;
import com.open.api.sdk.util.codec.ShaUtil;
import org.junit.Test;

public class TestSDK {

    private static String gatewayServerHttps = "https://175.45.19.41:5013";
    private static String devAccount = "foo";
    //test->hktest
    private static String sdkAppId = "BdcICECj2g1yqR3BkXoz";
    private static String p12Path = "D:环联资讯有限公司_ecdsa.p12";

    private static String p12Pwd = "hkstp5";
    private static String agencyWeid = "did:weid:1:0x03b809027f6494c784c21cc973f1911cc7210f33"; // 这个是机构对应的weid


    //查詢機構DID信息
    @Test
    public void testQueryAuthorityIssuer() {

        String json = "{\n" +
                "    \"functionArg\": {\n" +
                "        \"weId\": \""+agencyWeid+"\"\n" +
                "    },\n" +
                "    \"transactionArg\": {\n" +

                "    },\n" +
                "    \"v\": \"1.0.0\",\n" +
                "    \"functionName\": \"queryAuthorityIssuer\"\n" +
                "}";
        invokeHttps(json);


    }

    //hash上鏈及驗證
    @Test
    public void testUploadVerifyHashWithHttps() {

        long reqTime = System.currentTimeMillis();
        String hashValue = ShaUtil.getHash(String.valueOf(reqTime));

        String json = "{\n" +
                "    \"functionArg\": {\n" +
                "        \"hash\": \""+hashValue+"\"\n" +
                "    },\n" +
                "    \"transactionArg\": {\n" +
                "    \t\"businessType\": \"征信行业\",\n" +
                "    \t\"serviceName\": \"环联资讯有限公司\",\n" +
                "    \t\"invokerWeId\": \""+agencyWeid+"\",\n" +
                "    \t\"requestTime\": \""+reqTime+"\"\n" +
                "    },\n" +
                "    \"v\": \"1.0.0\",\n" +
                "    \"functionName\": \"uploadHash\"\n" +
                "}";
        invokeHttps(json);


//    hashValue = "";

        String verifyJson = "{\n" +
                "    \"functionArg\": {\n" +
                "        \"hashValue\": \""+hashValue+"\"\n" +
                "    },\n" +
                "    \"transactionArg\": {\n" +
                "    \t\"serviceName\": \"环联资讯有限公司\",\n" +
                "    \t\"businessType\": \"征信行业\",\n" +
                "    \t\"transNo\": \""+ CommonUtil.getTransNo()  +"\",\n" +
                "    \t\"requestTime\": \""+reqTime+"\"\n" +
                "    },\n" +
                "    \"v\": \"1.0.0\",\n" +
                "    \"functionName\": \"getEvidence\"\n" +
                "}";
        invokeHttps(verifyJson);

    }

    @Test
    public void testGetEvidenceWithHttps() {
        String hashValue = "0x4811561380166419007c545367d9ece39579627be0e739a4b9117177f2d4363d";
        String verifyJson = "{\n" +
                "    \"functionArg\": {\n" +
                "        \"hashValue\": \""+hashValue+"\"\n" +
                "    },\n" +
                "    \"transactionArg\": {\n" +
                "    \t\"serviceName\": \"环联资讯有限公司\",\n" +
                "    \t\"businessType\": \"征信行业\",\n" +
                "    \t\"transNo\": \""+ CommonUtil.getTransNo() +"\",\n" +
                "    \t\"requestTime\": \""+System.currentTimeMillis()+"\"\n" +
                "    },\n" +
                "    \"v\": \"1.0.0\",\n" +
                "    \"functionName\": \"getEvidence\"\n" +
                "}";
        invokeHttps(verifyJson);
    }


    @Test
    public void testGetHash() {

        String hash = ShaUtil.getHash("" + System.currentTimeMillis());
        System.out.println(hash);
    }

    @Test
    public void testGetFilenHash() {

        String hash = null;
        try {
            hash = ShaUtil.getFileHash("D:环联资讯有限公司_ecdsa.p12");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        System.out.println(hash);

        System.out.println(CommonUtil.getTransNo());
    }

    private static void invokeHttps(String json) {
        JSONObject jsonObject = new JSONObject(json);
        Object resp = null;
        try {
            MultiFiscoClient multiFiscoClient = new MultiFiscoClient(
                    gatewayServerHttps ,// 网关地址
                    devAccount, // 开发者账号，用agencyId代替
                    sdkAppId,    // 应用的 sdkAppId
                    p12Path, // p12 私钥文件路径
                    p12Pwd,
                    true);    // p12 私钥文件密码
            resp = multiFiscoClient.weIdInvokeHttps(jsonObject);
            System.out.println(resp.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
